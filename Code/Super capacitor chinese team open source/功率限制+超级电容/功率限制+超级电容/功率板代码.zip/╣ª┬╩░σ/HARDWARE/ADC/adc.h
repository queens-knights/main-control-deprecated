#ifndef __ADC_H
#define __ADC_H
#include "sys.h"
void Adc_Int(void);












#endif
